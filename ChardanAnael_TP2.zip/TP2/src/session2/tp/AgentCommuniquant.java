package session2.tp;

public interface AgentCommuniquant extends Agent, Canal {
}
