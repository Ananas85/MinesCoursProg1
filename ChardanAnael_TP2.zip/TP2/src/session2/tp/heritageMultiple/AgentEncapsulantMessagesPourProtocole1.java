package session2.tp.heritageMultiple;

public class AgentEncapsulantMessagesPourProtocole1 extends CanalOutProtocole1 implements AgentEncapsulantMessages {
    public AgentEncapsulantMessagesPourProtocole1() {
    }
}
