package session2.tp.heritageMultiple;

public class AgentEncapsulantMessagesPourProtocole2 extends CanalOutProtocole2 implements AgentEncapsulantMessages {
    public AgentEncapsulantMessagesPourProtocole2() {
    }
}
