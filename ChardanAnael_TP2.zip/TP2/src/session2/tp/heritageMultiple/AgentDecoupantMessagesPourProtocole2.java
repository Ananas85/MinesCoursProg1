package session2.tp.heritageMultiple;

public class AgentDecoupantMessagesPourProtocole2 extends CanalOutProtocole2 implements AgentDecoupantMessages {
    public AgentDecoupantMessagesPourProtocole2() {
    }
}
