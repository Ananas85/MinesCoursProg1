package session2.tp.heritageMultiple;

public class AgentDecoupantMessagesPourProtocole1 extends CanalOutProtocole1 implements AgentDecoupantMessages {
    public AgentDecoupantMessagesPourProtocole1() {
    }
}
