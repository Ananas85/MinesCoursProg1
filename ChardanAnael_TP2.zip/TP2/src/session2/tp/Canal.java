package session2.tp;

public interface Canal {
    public void emettre(String msg);
}
