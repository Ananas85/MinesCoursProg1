package session2.tp;

public interface Agent {
    public void envoyer(String msg);
}
