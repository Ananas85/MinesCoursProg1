package ModType16_dev.hierarchie;

public interface Corps<T> extends AnneauUnitaire<T>, GroupeMultiplicatif<T>, BiSymetrique<T> {

}
