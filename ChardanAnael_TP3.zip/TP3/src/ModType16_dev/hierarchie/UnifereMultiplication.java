package ModType16_dev.hierarchie;

public interface UnifereMultiplication<T> {
	T un();
}
