package ModType16_dev.hierarchie;

public interface SymetriqueAddition<T> {
	T oppose();
}
