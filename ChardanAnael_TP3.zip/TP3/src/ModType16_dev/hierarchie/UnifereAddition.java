package ModType16_dev.hierarchie;

public interface UnifereAddition<T> {
	T zero();
}
