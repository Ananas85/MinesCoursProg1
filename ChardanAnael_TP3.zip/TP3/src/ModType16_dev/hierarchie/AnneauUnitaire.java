package ModType16_dev.hierarchie;

public interface AnneauUnitaire<T> extends SemiAnneauUnitaire<T>, Anneau<T> {

}
