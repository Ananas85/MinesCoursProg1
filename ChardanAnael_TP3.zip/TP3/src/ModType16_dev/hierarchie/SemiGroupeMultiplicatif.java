package ModType16_dev.hierarchie;

public interface SemiGroupeMultiplicatif<T> {
	T produit( T x );
}
