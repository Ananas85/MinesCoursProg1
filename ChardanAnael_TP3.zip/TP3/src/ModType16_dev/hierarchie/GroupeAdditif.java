package ModType16_dev.hierarchie;

public interface GroupeAdditif<T> extends MonoideAdditif<T>, SymetriqueAddition<T> {
}
