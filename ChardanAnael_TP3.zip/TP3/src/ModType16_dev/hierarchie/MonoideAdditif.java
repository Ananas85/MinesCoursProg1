package ModType16_dev.hierarchie;

public interface MonoideAdditif<T> extends SemiGroupeAdditif<T>, UnifereAddition<T> {
}
