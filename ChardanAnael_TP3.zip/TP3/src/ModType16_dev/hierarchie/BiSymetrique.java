package ModType16_dev.hierarchie;

public interface BiSymetrique<T> extends SymetriqueAddition<T>, SymetriqueMultiplication<T> {

}
