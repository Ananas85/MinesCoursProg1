package ModType16_dev.hierarchie;

public interface BiUnifere<T> extends UnifereAddition<T>, UnifereMultiplication<T> {

}
