package ModType16_dev.hierarchie;

public interface SemiAnneau<T> extends MonoideAdditif<T>, SemiGroupeMultiplicatif<T> {
	
}
