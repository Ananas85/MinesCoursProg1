package ModType16_dev.hierarchie;

public interface Anneau<T> extends SemiAnneau<T>, GroupeAdditif<T> {

}
