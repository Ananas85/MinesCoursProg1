package ModType16_dev.hierarchie;

public interface SemiGroupeAdditif<T> {
	T somme( T x );
}
