package ModType16_dev.hierarchie;

public interface MonoideMultiplicatif<T> extends SemiGroupeMultiplicatif<T>, UnifereMultiplication<T> {
}
