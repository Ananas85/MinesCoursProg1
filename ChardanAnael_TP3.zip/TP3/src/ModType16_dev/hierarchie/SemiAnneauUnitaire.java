package ModType16_dev.hierarchie;

public interface SemiAnneauUnitaire<T> extends SemiAnneau<T>, MonoideMultiplicatif<T>, BiUnifere<T>{
}
