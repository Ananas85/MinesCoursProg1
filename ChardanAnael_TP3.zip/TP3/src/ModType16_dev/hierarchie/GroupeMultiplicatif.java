package ModType16_dev.hierarchie;

public interface GroupeMultiplicatif<T> extends MonoideMultiplicatif<T>, SymetriqueMultiplication<T> {
}
