package ModType16_dev.hierarchie;

public interface SymetriqueMultiplication<T> {
	T inverse();
}
