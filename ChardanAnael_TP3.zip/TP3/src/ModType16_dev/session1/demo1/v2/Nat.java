package ModType16_dev.session1.demo1.v2;

public interface Nat {
	Nat somme( Nat x );

	int chiffre( int i );

	int taille();

	int getInt();
}
