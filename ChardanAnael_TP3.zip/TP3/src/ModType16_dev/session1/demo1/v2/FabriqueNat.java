package ModType16_dev.session1.demo1.v2;

public interface FabriqueNat {
    Nat creerNatAvecValeur( int x );
    Nat creerNatAvecRepresentation( String repDecimale );
}
