package ModType16_dev.session3.demo.patrons.heritageMultiple;

import  ModType16_dev.session3.demo.patrons.agregationDelegation.CanalOutProtocole1;

public class AgentDecoupantMessagesPourProtocole1 extends CanalOutProtocole1 implements AgentDecoupantMessages {

}
