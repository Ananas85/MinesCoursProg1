package ModType16_dev.session3.demo.patrons.heritageMultiple;

import ModType16_dev.session3.demo.patrons.agregationDelegation.CanalOutProtocole2;

public class AgentDecoupantMessagesPourProtocole2 extends CanalOutProtocole2 implements AgentDecoupantMessages {

}
