package ModType16_dev.session3.demo.patrons.agregationDelegation;

public interface Agent {
	void envoyer( String msg );
}
