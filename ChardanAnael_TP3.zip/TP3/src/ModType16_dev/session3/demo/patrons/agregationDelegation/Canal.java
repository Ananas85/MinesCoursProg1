package ModType16_dev.session3.demo.patrons.agregationDelegation;

public interface Canal {
	void emettre( String msg );
}
