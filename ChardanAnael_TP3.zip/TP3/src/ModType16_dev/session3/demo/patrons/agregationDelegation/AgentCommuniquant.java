package ModType16_dev.session3.demo.patrons.agregationDelegation;


public interface AgentCommuniquant extends Agent, Canal {

}
