package ModType16_dev.session3.demo.patrons.observateur;

public enum ModeCommunication {
	PUSH, PULL;
}
