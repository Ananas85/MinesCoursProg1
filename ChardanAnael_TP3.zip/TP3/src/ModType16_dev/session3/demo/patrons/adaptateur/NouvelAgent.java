package ModType16_dev.session3.demo.patrons.adaptateur;

public interface NouvelAgent {
	void envoyer( String enTete, String msg );
}
